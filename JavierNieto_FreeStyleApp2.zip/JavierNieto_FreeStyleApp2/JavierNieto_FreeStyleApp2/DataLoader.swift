//
//  DataLoader.swift
//  JavierNieto_FreeStyleApp2
//
//  Created by X on 6/26/20.
//  Copyright © 2020 X. All rights reserved.
//

import Foundation

public class DataLoader {
    
    @Published var userData = [ReadingData]()
    init(){
        load()
    }
    
    func load(){
        if let fileLocation = Bundle.main.url(forResource: "mydata", withExtension: "json"){
            
            // do catch in case of an error
            do {
                let data = try Data(contentsOf: fileLocation)
                let jsonDecoder = JSONDecoder()
                let dataFromJson = try jsonDecoder.decode([ReadingData].self, from: data)//decode([JSONDecoder].self, from: data)
                
                self.userData = dataFromJson
            } catch {
                print(error)
            }
        }
    }
    func sort() {
        self.userData = self.userData.sorted(by: { $0.roomnum < $1.roomnum })
    }
}
