//
//  SelfSizingTableViewCell.swift
//  JavierNieto_FreeStyleApp2
//
//  Created by X on 6/26/20.
//  Copyright © 2020 X. All rights reserved.
//

import UIKit

class SelfSizingTableViewCell: UITableViewCell {
    @IBOutlet weak var cellLabelText: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
