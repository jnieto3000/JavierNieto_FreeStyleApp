//
//  ChartVC.swift
//  JavierNieto_FreeStyleApp2
//
//  Created by X on 6/27/20.
//  Copyright © 2020 X. All rights reserved.
//

import UIKit
import Charts

class ChartVC: UIViewController, ChartViewDelegate {

    var jsonData = DataLoader().userData
    var months: [String]!
    
    @IBOutlet weak var lineChartView: LineChartView!
    @IBOutlet weak var barChartView: BarChartView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //drawLineChartValues using JSON object  DataLoader().userData
        drawLineChartValues()
        
        //Bar Chart starts
        barChartView.delegate = self
        
        months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        let unitsSold = [20.0, 4.0, 6.0, 3.0, 12.0, 16.0, 4.0, 18.0, 2.0, 4.0, 5.0, 4.0]
        
        setBarChart(dataPoints: months, values: unitsSold)
    }

    func drawLineChartValues() {
        //let jsonData = jsonXData.data
         let count = jsonData.count
        // setChartValues(count)
         
         let values = (0..<count).map { (i) -> ChartDataEntry in
             let val = Double(jsonData[i].celsius )
             return ChartDataEntry(x: Double(i), y : val!)
          }
        
          let set1 = LineChartDataSet(entries: values, label: "Celsius")
          let data = LineChartData(dataSet: set1)
       // let d = LineChartDataSet(
         lineChartView.xAxis.labelPosition = .bottom
        //lineChartView.yAxis
          
         self.lineChartView.data = data
    }

    

    @IBAction func pinchDetected(_ sender: UIPinchGestureRecognizer) {
    lineChartView.transform = CGAffineTransform(scaleX: sender.scale, y: sender.scale)
    }
    

    
    func setBarChart(dataPoints: [String], values: [Double]) {
        //barChartView.noDataText = "You need to provide data for the chart."
        var dataEntries: [BarChartDataEntry] = []
        
        for i in 0..<dataPoints.count {
            //-let dataEntry = BarChartDataEntry(x: Double(i), y: values[i])
            let dataEntry = BarChartDataEntry(x: Double(i), y: values[i])
            //let dataEntry = BarChartDataEntry(value: values[i], xIndex: i)
            dataEntries.append(dataEntry)
        }
        
        let chartDataSet = BarChartDataSet(entries: dataEntries, label: "Test Data")
        //let chartDataSet = BarChartDataSet(yVals: dataEntries, label: "Units Sold")
        chartDataSet.colors = [UIColor(red: 230/255, green: 126/255, blue: 34/255, alpha: 1)]
        //chartDataSet.colors = ChartColorTemplates.colorful()
        barChartView.xAxis.labelPosition = .bottom
        let chartData = BarChartData(dataSet: chartDataSet)
       
        barChartView.animate(xAxisDuration: 2.0, yAxisDuration: 2.0, easingOption: .easeInBounce)
        
        let ll = ChartLimitLine(limit: 10.0, label: "Target")
        barChartView.rightAxis.addLimitLine(ll)
        //let chartData = BarChartData(xVals: months, dataSet: chartDataSet)
        
        barChartView.data = chartData
        
    }

//Random line Chart - testing
    func setChartValues(_ count : Int = 20){
        let values = (0..<count).map { (i) -> ChartDataEntry in
            let val = Double(arc4random_uniform(UInt32(count)) + 3 )
            return ChartDataEntry(x: Double(i), y : val)
        }
        let set1 = LineChartDataSet(entries: values, label: "DataSet 1")
        let data = LineChartData(dataSet: set1)
        
        
        self.lineChartView.data = data
    }

    
    //    func chartValueSelected(chartView: ChartVC, entry: ChartDataEntry, dataSetIndex: Int, highlight: Highlight) {
    //        print("\(entry.value) in \(months[entry.xIndex])")
    //  }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
