//
//  WebVC.swift
//  JavierNieto_FreeStyleApp2
//
//  Created by X on 6/28/20.
//  Copyright © 2020 X. All rights reserved.
//

import UIKit
import WebKit

class WebVC: UIViewController, WKNavigationDelegate {
    var link1: String = "http://192.168.43.249/"
    var link2: String = "http://192.168.43.92"

    @IBOutlet weak var webView: WKWebView!
    
        override func loadView() {
            webView = WKWebView()
            webView.navigationDelegate = self
            view = webView
        }
    
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            let url = URL(string: link1)!
            webView.load(URLRequest(url: url))
            webView.allowsBackForwardNavigationGestures = true
        }

    }
